# Create your views here.
from django.http import HttpResponse
  
def login(request):
  if request.user.is_authenticated():
    print request.user ;
    return HttpResponse('login in ')
  else:
    return HttpResponse('not login')